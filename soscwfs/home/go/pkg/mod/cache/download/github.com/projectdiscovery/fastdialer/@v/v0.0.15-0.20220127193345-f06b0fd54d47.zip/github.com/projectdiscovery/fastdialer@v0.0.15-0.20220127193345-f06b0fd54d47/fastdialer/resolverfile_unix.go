// +build !windows

package fastdialer

// ResolverFilePath in unix file os
const ResolverFilePath = "/etc/resolv.conf"
