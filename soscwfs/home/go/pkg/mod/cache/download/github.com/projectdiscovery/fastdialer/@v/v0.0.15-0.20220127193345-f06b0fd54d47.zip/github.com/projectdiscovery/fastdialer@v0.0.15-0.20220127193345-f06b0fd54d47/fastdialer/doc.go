// fastdialer is a dialer package containing a dns/tls cache layer
package fastdialer
