# Overview

[![Go Reference](https://pkg.go.dev/badge/github.com/ysmood/gson.svg)](https://pkg.go.dev/github.com/ysmood/gson)

A tiny JSON lib to read and alter a JSON value. The data structure is lazy, it's parse-on-read so that you can replace the parser with a faster one if performance is critical, use method `JSON.Raw` to do it.
