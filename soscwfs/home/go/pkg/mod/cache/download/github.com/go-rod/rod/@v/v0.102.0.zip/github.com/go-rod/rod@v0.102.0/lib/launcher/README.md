# Overview

A lib helps to find, launch or download the browser. You can also use it as a standalone lib without Rod.
