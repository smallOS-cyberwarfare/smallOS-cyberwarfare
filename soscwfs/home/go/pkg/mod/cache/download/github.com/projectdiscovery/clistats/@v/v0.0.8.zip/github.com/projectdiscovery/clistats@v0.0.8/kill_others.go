// +build freebsd openbsd dragonfly plan9 netbsd

package clistats

func kill() {
	// not implemented
}
