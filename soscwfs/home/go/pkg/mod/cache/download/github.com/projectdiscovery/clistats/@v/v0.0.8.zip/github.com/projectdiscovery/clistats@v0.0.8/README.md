# clistats
 
A command line statistics display library for golang.