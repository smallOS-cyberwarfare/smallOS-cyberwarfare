package cache

// Forked and adapted from https://github.com/patrickmn/go-cache
