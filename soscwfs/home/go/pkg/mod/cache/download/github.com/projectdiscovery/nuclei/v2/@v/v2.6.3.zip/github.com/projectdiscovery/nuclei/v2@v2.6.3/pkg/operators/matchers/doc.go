// Package matchers implements matchers for http response
// matching with templates.
package matchers
