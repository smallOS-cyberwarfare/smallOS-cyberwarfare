// Package uiprogress is a library to render progress bars in terminal applications
package uiprogress
