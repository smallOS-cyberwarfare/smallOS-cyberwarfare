# retryablehttp

Heavily inspired from [https://github.com/hashicorp/go-retryablehttp](https://github.com/hashicorp/go-retryablehttp).
