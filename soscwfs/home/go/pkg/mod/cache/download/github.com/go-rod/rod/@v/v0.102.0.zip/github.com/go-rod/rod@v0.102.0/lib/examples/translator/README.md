# Run the Example

```bash
go run . 茶叶蛋
```
