# input

A lib to help encode inputs.

Copied from [chromedp](https://github.com/chromedp/chromedp). But modified to make it completely independent.
