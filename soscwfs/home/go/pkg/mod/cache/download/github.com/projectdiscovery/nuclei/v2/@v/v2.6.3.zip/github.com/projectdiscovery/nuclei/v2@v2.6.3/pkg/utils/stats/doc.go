// Package stats provides a storage mechanism for storing
// and display vital statistics of the engine at various durations.
package stats
