# The RC2 Cipher in Golang

You know if you need this. And if you do, I'm sorry.

It's a crypto/cipher cipher.Block interface, just like AES.

It only works with 64 bidget keys right now, because, really, come on.

