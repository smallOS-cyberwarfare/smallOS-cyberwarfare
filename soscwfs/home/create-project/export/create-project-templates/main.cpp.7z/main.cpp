#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
  
  cin.get();
  return 0;
}
