fn main() {
  print!("Hello World");
}
