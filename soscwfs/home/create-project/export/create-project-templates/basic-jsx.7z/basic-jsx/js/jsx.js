const jsx = {
    createElement: (name, props = {}, ...content) => {
        let propsStr = "";
        if (props) {
            propsStr = Object.keys(props)
                .map(key => {
                const value = props[key];
		if (key === "style") {
                  const styleProps = Object.keys(value);
		  const tag = document.createElement("div");
		  for(let i in styleProps) {
                    tag.style[styleProps[i]] = value[styleProps[i]];
		  }
                    return `style=${tag.outerHTML.substring(11, tag.outerHTML.length - 7)}`;
		}

                return (key === "className" ? `class="${value}"` : `${key}="${value}"`);
            }).join(" ");
        }
        if (name[0] === "<") {
            if (propsStr === "") {
                return name;
            }
            else {
                return name.replace(">", ` ${propsStr}>`);
            }
        }
        if (propsStr === "") {
            if (name !== "internalfragment") {
                return `<${name}>${content.join("")}</${name}>`;
            }
            else {
                return `${content.join("")}`;
            }
        }
        else {
            return `<${name} ${propsStr}>${content.join("")}</${name}>`;
        }
    },
    Fragment: "internalfragment",
};
jsx.render = (elem1, elem2) => {
    elem2.innerHTML = elem1;
};
export default jsx;
