Vue.component("web-header", {
  template: "<header><h1>{{title}}</h1></header>",
  computed: {
    title: function() {
      return "Hello";
    }
  }
});

Vue.component('web-footer', {
  template: '<footer><h6 class="innerFooter">Copyrigth &copy; {{currentYear}}</h6></footer>',
  computed: {
    currentYear: function() {
      return new Date().getFullYear();
    }
  }
});
