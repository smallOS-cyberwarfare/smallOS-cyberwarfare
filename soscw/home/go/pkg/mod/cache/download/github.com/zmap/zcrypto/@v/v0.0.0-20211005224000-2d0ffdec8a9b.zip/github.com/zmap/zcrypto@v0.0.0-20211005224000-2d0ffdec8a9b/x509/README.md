Originally based on the go/crypto/x509 standard library,
this package has now diverged enough that it is no longer
updated with direct correspondence to new go releases.

Approximately supports all the features of
github.com/golang/go/crypto/x509 package at:
branch: release-branch.go1.10
revision: dea961ebd9f871b39b3bdaab32f952037f28cd71
