# filekv

file based kv store with optional dedupe mechanism via bloom filters (only supports set and scan operations)
