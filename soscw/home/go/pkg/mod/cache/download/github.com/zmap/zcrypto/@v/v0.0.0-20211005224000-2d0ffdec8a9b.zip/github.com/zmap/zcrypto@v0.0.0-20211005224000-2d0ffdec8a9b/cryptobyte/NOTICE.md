Forked from golang.org/x/crypto/cryptobyte in order to support 
permissive asn1 parsing.