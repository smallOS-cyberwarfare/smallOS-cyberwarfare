package shared

// Version ...
const Version = "34a05a9dc363ec03e25d5dcc5ff915d2"
