# fileutil
The package contains various helpers to interact with files